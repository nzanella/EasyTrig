#!/bin/sh

# Colors for function names and arguments to be presented to user.

color_funcnamesargs_dvipng="rgb 1.0 0.0 1.0" # magenta
color_funcnamesargs_convert="#ff00ff" # magenta

# Colors for function definitions used in presenting solution.

color_funcnamedefs_dvipng="rgb 1.0 0.0 0.0" # red
color_funcnamedefs_convert="#ff0000" # red

# Colors for function arguments to surround graph.

color_funcargs_dvipng="rgb 1.0 0.0 0.0" # red
color_funcargs_convert="#ff0000" # red

# Colors for function sides to surround triangle.

color_sidedefs_dvipng="rgb 1.0 0.0 0.0" # red
color_sidedefs_convert="#ff0000" # red

# Colors for function names and arguments to surround screen.

color_funcval_pressed_dvipng="rgb 1.0 1.0 1.0"   # white
color_funcval_ansright_dvipng="rgb 1.0 1.0 0.0"   # yellow
color_funcval_answrong_dvipng="rgb 1.0 0.4 0.0"  # orange
color_funcval_default_dvipng="rgb 0.0 1.0 1.0"   # cyan
color_funcval_pressed_convert="#ffffff"  # white
color_funcval_ansright_convert="#ffff00"  # yellow
color_funcval_answrong_convert="#ff6600" # orange
color_funcval_default_convert="#00ffff"  # cyan

echo "Running LaTeX..."

latex trignames.tex
latex trignamedefs.tex
latex trigargsdeg.tex
latex trigargsrad.tex
latex trigvals.tex
latex trigsides.tex

echo "Creating drawable directory..."

mkdir -p drawable
cd drawable

echo "Converting DVI files to PNG file format..."

dvipng -bg "$color_funcnamesargs_dvipng" -o funcname_%d.png ../trignames.dvi
dvipng -bg "$color_funcnamesargs_dvipng" -o funcargdeg_%d.png ../trigargsdeg.dvi
dvipng -bg "$color_funcnamesargs_dvipng" -o funcargrad_%d.png ../trigargsrad.dvi

dvipng -bg "$color_funcnamedefs_dvipng" -o funcnamedef_%d.png ../trignamedefs.dvi

dvipng -bg "$color_funcargs_dvipng" -o funcargdegsmall_%d.png ../trigargsdeg.dvi
dvipng -bg "$color_funcargs_dvipng" -o funcargradsmall_%d.png ../trigargsrad.dvi

dvipng -bg "$color_sidedefs_dvipng" -o sidedef_%d.png ../trigsides.dvi

dvipng -bg "$color_funcval_pressed_dvipng" -o funcval_pressed_%d.png ../trigvals.dvi
dvipng -bg "$color_funcval_ansright_dvipng" -o funcval_ansright_%d.png ../trigvals.dvi
dvipng -bg "$color_funcval_answrong_dvipng" -o funcval_answrong_%d.png ../trigvals.dvi
dvipng -bg "$color_funcval_default_dvipng" -o funcval_default_%d.png ../trigvals.dvi

echo "Renaming files..."

  # Trigonometric function names.

  mv funcname_1.png funcname_sin.png
  mv funcname_2.png funcname_cos.png
  mv funcname_3.png funcname_tan.png
  mv funcname_4.png funcname_sec.png
  mv funcname_5.png funcname_csc.png
  mv funcname_6.png funcname_cot.png

  # Trigonometric function name definitions.

  mv funcnamedef_1.png funcnamedef_sin.png
  mv funcnamedef_2.png funcnamedef_cos.png
  mv funcnamedef_3.png funcnamedef_tan.png
  mv funcnamedef_4.png funcnamedef_sec.png
  mv funcnamedef_5.png funcnamedef_csc.png
  mv funcnamedef_6.png funcnamedef_cot.png

   # Degree angles to be used as trigonometric function arguments.

for i in "" "small"; do

  mv funcargdeg${i}_1.png funcargdeg${i}_zero.png
  mv funcargdeg${i}_2.png funcargdeg${i}_plus30.png
  mv funcargdeg${i}_3.png funcargdeg${i}_minus30.png
  mv funcargdeg${i}_4.png funcargdeg${i}_plus45.png
  mv funcargdeg${i}_5.png funcargdeg${i}_minus45.png
  mv funcargdeg${i}_6.png funcargdeg${i}_plus60.png
  mv funcargdeg${i}_7.png funcargdeg${i}_minus60.png
  mv funcargdeg${i}_8.png funcargdeg${i}_plus90.png
  mv funcargdeg${i}_9.png funcargdeg${i}_minus90.png
  mv funcargdeg${i}_10.png funcargdeg${i}_plus120.png
  mv funcargdeg${i}_11.png funcargdeg${i}_minus120.png
  mv funcargdeg${i}_12.png funcargdeg${i}_plus135.png
  mv funcargdeg${i}_13.png funcargdeg${i}_minus135.png
  mv funcargdeg${i}_14.png funcargdeg${i}_plus150.png
  mv funcargdeg${i}_15.png funcargdeg${i}_minus150.png
  mv funcargdeg${i}_16.png funcargdeg${i}_plus180.png
  mv funcargdeg${i}_17.png funcargdeg${i}_minus180.png
  mv funcargdeg${i}_18.png funcargdeg${i}_plus210.png
  mv funcargdeg${i}_19.png funcargdeg${i}_minus210.png
  mv funcargdeg${i}_20.png funcargdeg${i}_plus225.png
  mv funcargdeg${i}_21.png funcargdeg${i}_minus225.png
  mv funcargdeg${i}_22.png funcargdeg${i}_plus240.png
  mv funcargdeg${i}_23.png funcargdeg${i}_minus240.png
  mv funcargdeg${i}_24.png funcargdeg${i}_plus270.png
  mv funcargdeg${i}_25.png funcargdeg${i}_minus270.png
  mv funcargdeg${i}_26.png funcargdeg${i}_plus300.png
  mv funcargdeg${i}_27.png funcargdeg${i}_minus300.png
  mv funcargdeg${i}_28.png funcargdeg${i}_plus315.png
  mv funcargdeg${i}_29.png funcargdeg${i}_minus315.png
  mv funcargdeg${i}_30.png funcargdeg${i}_plus330.png
  mv funcargdeg${i}_31.png funcargdeg${i}_minus330.png
  mv funcargdeg${i}_32.png funcargdeg${i}_plus360.png
  mv funcargdeg${i}_33.png funcargdeg${i}_minus360.png

  # Radian angles to be used as trigonometric function arguments.

  mv funcargrad${i}_1.png funcargrad${i}_zero.png
  mv funcargrad${i}_2.png funcargrad${i}_plus_frac_pi_6.png
  mv funcargrad${i}_3.png funcargrad${i}_minus_frac_pi_6.png
  mv funcargrad${i}_4.png funcargrad${i}_plus_frac_pi_4.png
  mv funcargrad${i}_5.png funcargrad${i}_minus_frac_pi_4.png
  mv funcargrad${i}_6.png funcargrad${i}_plus_frac_pi_3.png
  mv funcargrad${i}_7.png funcargrad${i}_minus_frac_pi_3.png
  mv funcargrad${i}_8.png funcargrad${i}_plus_frac_pi_2.png
  mv funcargrad${i}_9.png funcargrad${i}_minus_frac_pi_2.png
  mv funcargrad${i}_10.png funcargrad${i}_plus_frac_2pi_3.png
  mv funcargrad${i}_11.png funcargrad${i}_minus_frac_2pi_3.png
  mv funcargrad${i}_12.png funcargrad${i}_plus_frac_3pi_4.png
  mv funcargrad${i}_13.png funcargrad${i}_minus_frac_3pi_4.png
  mv funcargrad${i}_14.png funcargrad${i}_plus_frac_5pi_6.png
  mv funcargrad${i}_15.png funcargrad${i}_minus_frac_5pi_6.png
  mv funcargrad${i}_16.png funcargrad${i}_plus_pi.png
  mv funcargrad${i}_17.png funcargrad${i}_minus_pi.png
  mv funcargrad${i}_18.png funcargrad${i}_plus_frac_7pi_6.png
  mv funcargrad${i}_19.png funcargrad${i}_minus_frac_7pi_6.png
  mv funcargrad${i}_20.png funcargrad${i}_plus_frac_5pi_4.png
  mv funcargrad${i}_21.png funcargrad${i}_minus_frac_5pi_4.png
  mv funcargrad${i}_22.png funcargrad${i}_plus_frac_4pi_3.png
  mv funcargrad${i}_23.png funcargrad${i}_minus_frac_4pi_3.png
  mv funcargrad${i}_24.png funcargrad${i}_plus_frac_3pi_2.png
  mv funcargrad${i}_25.png funcargrad${i}_minus_frac_3pi_2.png
  mv funcargrad${i}_26.png funcargrad${i}_plus_frac_5pi_3.png
  mv funcargrad${i}_27.png funcargrad${i}_minus_frac_5pi_3.png
  mv funcargrad${i}_28.png funcargrad${i}_plus_frac_7pi_4.png
  mv funcargrad${i}_29.png funcargrad${i}_minus_frac_7pi_4.png
  mv funcargrad${i}_30.png funcargrad${i}_plus_frac_11pi_6.png
  mv funcargrad${i}_31.png funcargrad${i}_minus_frac_11pi_6.png
  mv funcargrad${i}_32.png funcargrad${i}_plus_2pi.png
  mv funcargrad${i}_33.png funcargrad${i}_minus_2pi.png

done

  # Triangle sides definitions.

  mv sidedef_1.png sidedef_hyp_1.png
  mv sidedef_2.png sidedef_hyp_2.png
  mv sidedef_3.png sidedef_hyp_frac_2sqrt3_3.png
  mv sidedef_4.png sidedef_hyp_2sqrt3.png
  mv sidedef_5.png sidedef_hyp_sqrt2.png
  mv sidedef_6.png sidedef_adj_zero.png
  mv sidedef_7.png sidedef_adj_plus_frac_1_2.png
  mv sidedef_8.png sidedef_adj_plus_1.png
  mv sidedef_9.png sidedef_adj_plus_frac_sqrt3_3.png
  mv sidedef_10.png sidedef_adj_plus_sqrt3.png
  mv sidedef_11.png sidedef_adj_plus_frac_sqrt3_2.png
  mv sidedef_12.png sidedef_adj_plus_3.png
  mv sidedef_13.png sidedef_adj_plus_frac_sqrt2_2.png
  mv sidedef_14.png sidedef_adj_plus_2.png
  mv sidedef_15.png sidedef_adj_minus_frac_1_2.png
  mv sidedef_16.png sidedef_adj_minus_1.png
  mv sidedef_17.png sidedef_adj_minus_frac_sqrt3_3.png
  mv sidedef_18.png sidedef_adj_minus_sqrt3.png
  mv sidedef_19.png sidedef_adj_minus_frac_sqrt3_2.png
  mv sidedef_20.png sidedef_adj_minus_3.png
  mv sidedef_21.png sidedef_adj_minus_frac_sqrt2_2.png
  mv sidedef_22.png sidedef_adj_minus_2.png
  mv sidedef_23.png sidedef_opp_zero.png
  mv sidedef_24.png sidedef_opp_plus_frac_1_2.png
  mv sidedef_25.png sidedef_opp_plus_1.png
  mv sidedef_26.png sidedef_opp_plus_frac_sqrt3_3.png
  mv sidedef_27.png sidedef_opp_plus_sqrt3.png
  mv sidedef_28.png sidedef_opp_plus_frac_sqrt3_2.png
  mv sidedef_29.png sidedef_opp_plus_3.png
  mv sidedef_30.png sidedef_opp_plus_frac_sqrt2_2.png
  mv sidedef_31.png sidedef_opp_plus_2.png
  mv sidedef_32.png sidedef_opp_minus_frac_1_2.png
  mv sidedef_33.png sidedef_opp_minus_1.png
  mv sidedef_34.png sidedef_opp_minus_frac_sqrt3_3.png
  mv sidedef_35.png sidedef_opp_minus_sqrt3.png
  mv sidedef_36.png sidedef_opp_minus_frac_sqrt3_2.png
  mv sidedef_37.png sidedef_opp_minus_3.png
  mv sidedef_38.png sidedef_opp_minus_frac_sqrt2_2.png
  mv sidedef_39.png sidedef_opp_minus_2.png

for i in pressed ansright answrong default; do

  # Fractions to be used as trigonometric function values.

  mv funcval_${i}_1.png funcval_zero_$i.png
  mv funcval_${i}_2.png funcval_plus_frac_1_2_$i.png
  mv funcval_${i}_3.png funcval_minus_frac_1_2_$i.png
  mv funcval_${i}_4.png funcval_plus_frac_sqrt3_3_$i.png
  mv funcval_${i}_5.png funcval_minus_frac_sqrt3_3_$i.png
  mv funcval_${i}_6.png funcval_plus_frac_sqrt2_2_$i.png
  mv funcval_${i}_7.png funcval_minus_frac_sqrt2_2_$i.png
  mv funcval_${i}_8.png funcval_plus_frac_sqrt3_2_$i.png
  mv funcval_${i}_9.png funcval_minus_frac_sqrt3_2_$i.png
  mv funcval_${i}_10.png funcval_plus_1_$i.png
  mv funcval_${i}_11.png funcval_minus_1_$i.png
  mv funcval_${i}_12.png funcval_plus_frac_2sqrt3_3_$i.png
  mv funcval_${i}_13.png funcval_minus_frac_2sqrt3_3_$i.png
  mv funcval_${i}_14.png funcval_plus_sqrt2_$i.png
  mv funcval_${i}_15.png funcval_minus_sqrt2_$i.png
  mv funcval_${i}_16.png funcval_plus_sqrt3_$i.png
  mv funcval_${i}_17.png funcval_minus_sqrt3_$i.png
  mv funcval_${i}_18.png funcval_plus_2_$i.png
  mv funcval_${i}_19.png funcval_minus_2_$i.png
  mv funcval_${i}_20.png funcval_undefined_$i.png

done

echo "Extending and scaling files..."

for i in funcname_*.png funcargdeg_*.png funcargrad_*.png; do
  convert $i -background "$color_funcnamesargs_convert" -gravity Center -extent 120x80 $i
  convert $i -scale 64x48 $i
done

for i in funcnamedef_*.png; do
  convert $i -background "$color_funcnamedefs_convert" -gravity Center -extent 200x70 $i
  convert $i -scale 128x64 $i
done

for i in funcargdegsmall_*.png funcargradsmall_*.png; do
  convert $i -background "$color_funcargs_convert" -gravity Center -extent 120x120 $i
  convert $i -scale 38x38 $i
done

for i in sidedef_*.png; do
  convert $i -background "$color_sidedefs_convert" -gravity Center -extent 200x70 $i
  convert $i -scale 128x64 $i
done

for i in funcval_*_pressed.png; do
  convert $i -background "$color_funcval_pressed_convert" -gravity Center -extent 120x120 $i
  convert $i -scale 64x64 $i
done

for i in funcval_*_ansright.png; do
  convert $i -background "$color_funcval_ansright_convert" -gravity Center -extent 120x120 $i
  convert $i -scale 64x64 $i
done

for i in funcval_*_answrong.png; do
  convert $i -background "$color_funcval_answrong_convert" -gravity Center -extent 120x120 $i
  convert $i -scale 64x64 $i
done

for i in funcval_*_default.png; do
  convert $i -background "$color_funcval_default_convert" -gravity Center -extent 120x120 $i
  convert $i -scale 64x64 $i
done

echo "Building XML selector files..."

for file in funcval_*_default.png; do
  basename=`basename $file _default.png`
  sed -e "s/PRESSED/${basename}_pressed/g" -e "s/SELECTED/${basename}_default/g" -e "s/DEFAULT/${basename}_default/g" ../selector.template > ${basename}_selector.xml
done

echo "Done."
